/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package StudentData;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;
import POJOS.*;
import com.mysql.jdbc.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;



/**
 *
 * @author Brij
 */
public class Student_data  {

   public static Connection getConnection() {
        Connection con = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/student_java?user=root");
        } catch (Exception e) {
            System.out.println(e);
        }
        return con;
    }
   
   public static int Save(Student s) throws ClassNotFoundException, SQLException{
       int status = 0;
       Connection con = StudentData.Student_data.getConnection();
       PreparedStatement ps = (PreparedStatement) con.prepareStatement("INSERT INTO `student_data`( `name`, `email`, `enumber`, `pass`) VALUES (?,?,?,?)");
       ps.setString(1, s.getName());
            ps.setString(2, s.getEmail());
            ps.setString(3, s.getEnumber());
            ps.setString(4, s.getPass());
            status = ps.executeUpdate();
            con.close();
            return status;
            
   }

public static boolean check_user(String uname, String pass) {
        int status = 0;
        try {
            Statement stmt = null;
            Connection con = Student_data.getConnection();
            stmt = con.createStatement();

            String sql = "SELECT `id` FROM `student_data` WHERE `email`='"+uname+"'  AND `pass` ='"+pass+"'";
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                return true;
            }
            rs.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return false;
    }

public static ArrayList<String> Show_info() {
        int status = 0;
        ArrayList<String> ar= new ArrayList<String>();
        try {
            Statement stmt = null;
            Connection con = Student_data.getConnection();
            stmt = con.createStatement();

            String sql = "SELECT * FROM `student_data`";
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                String username = rs.getString("name");
                String password = rs.getString("pass");
                String email = rs.getString("email");
                String enumber = rs.getString("enumber");
                
                String s = username+" "+password+" "+email+" "+enumber;
                
                ar.add(s.toString());
                
            }
            rs.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
            
        return ar;
        
    }

}
