/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import POJOS.*;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Brij
 */
public class Student_Servlat extends HttpServlet {

   
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        
        try {
         resp.setContentType("text/html;charset=UTF-8");
        String name,email,e_num,pass;
        name = req.getParameter("name");
        email = req.getParameter("email");
        e_num = req.getParameter("enum");
        pass = req.getParameter("psw");
        Student se = new Student(name, email, pass, e_num);
            StudentData.Student_data.Save(se);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Student_Servlat.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Student_Servlat.class.getName()).log(Level.SEVERE, null, ex);
        }
        resp.sendRedirect("index.html");
    }

}
