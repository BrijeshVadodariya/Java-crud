import java.rmi.*;  
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.*;  
public class server extends UnicastRemoteObject implements adder
{  
    public server() throws RemoteException{
    }
    
    @Override
    public int add(int x, int y) throws RemoteException {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        return x+y;
    }
    public static void main(String []args) throws RemoteException{
        Registry reg = LocateRegistry.createRegistry(9959);
        reg.rebind("hi", new server());
        System.out.print("Server is ready");
         }

    @Override
    public int mul(int x, int y) throws RemoteException {
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
       return x*y;
    }
 
} 
