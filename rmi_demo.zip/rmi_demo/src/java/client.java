
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Scanner;
import javax.servlet.Registration;


public class client {
    public static void main(String[] args) throws RemoteException, NotBoundException{
    
    client c = new client();
    c.connectRemote();
    
    }
    
    private void connectRemote() throws RemoteException, NotBoundException{
        Scanner sc = new Scanner(System.in);
        Registry reg = LocateRegistry.getRegistry("localhost",9959);
        adder ad = (adder)reg.lookup("hi");
        System.out.println("enter two number");
        int a = sc.nextInt();
        int b = sc.nextInt();
        System.out.println("Sum of two number is :-  "+ad.add(a, b) + "  Mul is :- " + ad.mul(a, b));
    }
    
}
